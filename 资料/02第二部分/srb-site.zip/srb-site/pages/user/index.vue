<template>
  <div class="personal-main">
    用户中心
  </div>
</template>

<script>
export default {}
</script>
