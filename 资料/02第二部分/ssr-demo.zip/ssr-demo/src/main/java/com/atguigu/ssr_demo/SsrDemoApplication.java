package com.atguigu.ssr_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsrDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsrDemoApplication.class, args);
	}

}
